(function(){var p=Object.defineProperty;var c=(o,t,e)=>t in o?p(o,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):o[t]=e;var s=(o,t,e)=>c(o,typeof t!="symbol"?t+"":t,e);class u{constructor(){s(this,"settings",{laser:!1,spotlight:!1,keystroke:!0,privacy:!1,autoZoom:!1,teleprompter:!1,reduceMotion:!1});s(this,"rootContainer",null);s(this,"spotlightEl",null);s(this,"mousePos",{x:0,y:0});s(this,"laserCanvas",null);s(this,"laserCtx",null);s(this,"laserPoints",[]);s(this,"isDrawingLaser",!1);s(this,"laserAnimFrame",null);s(this,"keystrokeHudEl",null);s(this,"keystrokeTimeout",null);s(this,"privacyShieldEl",null);s(this,"zoomTimeout",null);s(this,"isZoomed",!1);this.checkReduceMotion(),this.initDOM(),this.bindEvents()}checkReduceMotion(){const t=window.matchMedia("(prefers-reduced-motion: reduce)");this.settings.reduceMotion=t.matches}initDOM(){if(document.getElementById("vs-overlay-root"))return;const t=document.createElement("div");t.id="vs-overlay-root",t.style.cssText=`
      position: fixed;
      inset: 0;
      pointer-events: none;
      z-index: 2147483640;
      overflow: hidden;
      font-family: Inter, system-ui, sans-serif;
    `,document.body.appendChild(t),this.rootContainer=t;const e=document.createElement("style");e.textContent=`
      @keyframes vs-ripple-expand {
        0% { transform: scale(0.2); opacity: 1; }
        100% { transform: scale(2.2); opacity: 0; }
      }
      @keyframes vs-hud-pop {
        0% { transform: translateY(12px) scale(0.95); opacity: 0; }
        100% { transform: translateY(0) scale(1); opacity: 1; }
      }
      .vs-click-ripple {
        position: fixed;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        border: 3px solid #A3E635;
        box-shadow: 0 0 16px rgba(163, 230, 53, 0.7);
        pointer-events: none;
        z-index: 2147483645;
        animation: vs-ripple-expand 0.45s ease-out forwards;
      }
    `,document.head.appendChild(e),this.initSpotlight(),this.initLaserCanvas(),this.initKeystrokeHud(),this.initPrivacyShield()}initSpotlight(){var e;const t=document.createElement("div");t.id="vs-spotlight",t.style.cssText=`
      position: fixed;
      inset: 0;
      pointer-events: none;
      display: none;
      z-index: 2147483642;
      transition: background 0.05s ease-out;
    `,(e=this.rootContainer)==null||e.appendChild(t),this.spotlightEl=t}updateSpotlight(t,e){!this.settings.spotlight||!this.spotlightEl||(this.spotlightEl.style.display="block",this.spotlightEl.style.background=`radial-gradient(circle 130px at ${t}px ${e}px, transparent 0%, transparent 120px, rgba(0, 0, 0, 0.65) 130px)`)}initLaserCanvas(){var e;const t=document.createElement("canvas");t.id="vs-laser-canvas",t.width=window.innerWidth,t.height=window.innerHeight,t.style.cssText=`
      position: fixed;
      inset: 0;
      pointer-events: none;
      display: none;
      z-index: 2147483643;
    `,(e=this.rootContainer)==null||e.appendChild(t),this.laserCanvas=t,this.laserCtx=t.getContext("2d"),window.addEventListener("resize",()=>{t.width=window.innerWidth,t.height=window.innerHeight}),this.startLaserRenderLoop()}startLaserRenderLoop(){const t=()=>{if(this.laserCtx&&this.laserCanvas){const e=Date.now();if(this.laserPoints=this.laserPoints.filter(i=>e-i.time<2e3),this.laserCtx.clearRect(0,0,this.laserCanvas.width,this.laserCanvas.height),this.laserPoints.length>1)for(let i=1;i<this.laserPoints.length;i++){const a=this.laserPoints[i-1],r=this.laserPoints[i],n=e-r.time,d=Math.max(0,1-n/2e3);this.laserCtx.beginPath(),this.laserCtx.moveTo(a.x,a.y),this.laserCtx.lineTo(r.x,r.y),this.laserCtx.lineWidth=6,this.laserCtx.lineCap="round",this.laserCtx.strokeStyle=`rgba(34, 211, 238, ${d})`,this.laserCtx.shadowColor="#22D3EE",this.laserCtx.shadowBlur=14,this.laserCtx.stroke()}}this.laserAnimFrame=requestAnimationFrame(t)};this.laserAnimFrame=requestAnimationFrame(t)}initKeystrokeHud(){var e;const t=document.createElement("div");t.id="vs-keystroke-hud",t.style.cssText=`
      position: fixed;
      bottom: 48px;
      left: 50%;
      transform: translateX(-50%);
      display: none;
      pointer-events: none;
      z-index: 2147483646;
      background: rgba(27, 28, 33, 0.92);
      backdrop-filter: blur(12px);
      border: 1px solid #383942;
      border-radius: 12px;
      padding: 8px 16px;
      color: #F5F5F7;
      font-size: 14px;
      font-weight: 700;
      font-family: 'JetBrains Mono', monospace;
      box-shadow: 0 12px 32px rgba(0, 0, 0, 0.6);
      animation: vs-hud-pop 0.15s cubic-bezier(0.2, 0, 0, 1) forwards;
    `,(e=this.rootContainer)==null||e.appendChild(t),this.keystrokeHudEl=t}displayKeystroke(t){!this.settings.keystroke||!this.keystrokeHudEl||(this.keystrokeHudEl.textContent=t,this.keystrokeHudEl.style.display="block",this.keystrokeTimeout&&clearTimeout(this.keystrokeTimeout),this.keystrokeTimeout=window.setTimeout(()=>{this.keystrokeHudEl&&(this.keystrokeHudEl.style.display="none")},2e3))}initPrivacyShield(){var n,d;const t=document.createElement("div");t.id="vs-privacy-shield",t.style.cssText=`
      position: fixed;
      top: 25%;
      left: 35%;
      width: 320px;
      height: 120px;
      display: none;
      z-index: 2147483644;
      pointer-events: auto;
      backdrop-filter: blur(18px);
      -webkit-backdrop-filter: blur(18px);
      background: rgba(255, 77, 79, 0.12);
      border: 2px dashed #FF4D4F;
      border-radius: 12px;
      box-shadow: 0 8px 24px rgba(255, 77, 79, 0.25);
      cursor: move;
      resize: both;
      overflow: hidden;
    `;const e=document.createElement("div");e.style.cssText=`
      padding: 4px 8px;
      background: rgba(255, 77, 79, 0.85);
      color: white;
      font-size: 10px;
      font-weight: 700;
      letter-spacing: 0.5px;
      text-transform: uppercase;
      display: flex;
      justify-content: space-between;
      align-items: center;
    `,e.innerHTML=`
      <span>🛡️ Privacy Blur Shield</span>
      <span style="cursor: pointer; padding: 0 4px;" id="vs-privacy-close">✕</span>
    `,t.appendChild(e);let i=!1,a=0,r=0;e.addEventListener("mousedown",l=>{i=!0,a=l.clientX-t.getBoundingClientRect().left,r=l.clientY-t.getBoundingClientRect().top}),window.addEventListener("mousemove",l=>{i&&(t.style.left=`${l.clientX-a}px`,t.style.top=`${l.clientY-r}px`)}),window.addEventListener("mouseup",()=>{i=!1}),(n=t.querySelector("#vs-privacy-close"))==null||n.addEventListener("click",()=>{this.toggleTool("privacy",!1)}),(d=this.rootContainer)==null||d.appendChild(t),this.privacyShieldEl=t}triggerAutoZoom(t,e){if(!this.settings.autoZoom||this.settings.reduceMotion)return;if(this.isZoomed){this.resetZoom();return}const i=window.innerWidth,a=window.innerHeight,r=t/i*100,n=e/a*100;document.body.style.transformOrigin=`${r}% ${n}%`,document.body.style.transition="transform 0.4s cubic-bezier(0.2, 0, 0, 1)",document.body.style.transform="scale(2)",this.isZoomed=!0,this.zoomTimeout&&clearTimeout(this.zoomTimeout),this.zoomTimeout=window.setTimeout(()=>{this.resetZoom()},2500)}resetZoom(){document.body.style.transition="transform 0.35s cubic-bezier(0.4, 0, 0.2, 1)",document.body.style.transform="scale(1)",this.isZoomed=!1,this.zoomTimeout&&clearTimeout(this.zoomTimeout)}triggerClickRipple(t,e){const i=document.createElement("div");i.className="vs-click-ripple",i.style.left=`${t-20}px`,i.style.top=`${e-20}px`,document.body.appendChild(i),setTimeout(()=>{i.remove()},450)}bindEvents(){window.addEventListener("mousemove",t=>{this.mousePos={x:t.clientX,y:t.clientY},this.settings.spotlight&&this.updateSpotlight(t.clientX,t.clientY),this.isDrawingLaser&&this.settings.laser&&this.laserPoints.push({x:t.clientX,y:t.clientY,time:Date.now()})}),window.addEventListener("mousedown",t=>{this.triggerClickRipple(t.clientX,t.clientY),this.settings.autoZoom&&this.triggerAutoZoom(t.clientX,t.clientY),this.settings.laser&&(this.isDrawingLaser=!0,this.laserPoints.push({x:t.clientX,y:t.clientY,time:Date.now()}))}),window.addEventListener("mouseup",()=>{this.isDrawingLaser=!1}),window.addEventListener("keydown",t=>{const e=t.target;if(e&&(e.tagName==="INPUT"||e.tagName==="TEXTAREA"||e.isContentEditable))return;const i=[];t.metaKey&&i.push("⌘"),t.ctrlKey&&i.push("Ctrl"),t.altKey&&i.push("Alt"),t.shiftKey&&i.push("Shift");const a=t.key.length===1?t.key.toUpperCase():t.key,r=[...i,a].join(" + ");if(this.displayKeystroke(r),t.altKey){const n=t.key.toLowerCase();n==="s"?(t.preventDefault(),this.toggleTool("spotlight")):n==="l"?(t.preventDefault(),this.toggleTool("laser")):n==="k"?(t.preventDefault(),this.toggleTool("keystroke")):n==="p"?(t.preventDefault(),this.toggleTool("privacy")):n==="z"&&(t.preventDefault(),this.toggleTool("autoZoom"))}})}toggleTool(t,e){const i=e!==void 0?e:!this.settings[t];this.settings[t]=i,t==="spotlight"?this.spotlightEl&&(this.spotlightEl.style.display=i?"block":"none",i&&this.updateSpotlight(this.mousePos.x,this.mousePos.y)):t==="laser"?this.laserCanvas&&(this.laserCanvas.style.display=i?"block":"none",i||(this.laserPoints=[])):t==="privacy"?this.privacyShieldEl&&(this.privacyShieldEl.style.display=i?"block":"none"):t==="autoZoom"&&!i&&this.isZoomed&&this.resetZoom()}getSettings(){return{...this.settings}}dispose(){var t;this.laserAnimFrame&&cancelAnimationFrame(this.laserAnimFrame),this.zoomTimeout&&clearTimeout(this.zoomTimeout),this.keystrokeTimeout&&clearTimeout(this.keystrokeTimeout),this.resetZoom(),(t=this.rootContainer)==null||t.remove()}}const h=new u;chrome.runtime.onMessage.addListener((o,t,e)=>{if(o.type==="TOGGLE_LIVE_TOOL"&&o.tool)return h.toggleTool(o.tool,o.state),e({success:!0,settings:h.getSettings()}),!0;if(o.type==="GET_LIVE_TOOLS_STATE")return e({settings:h.getSettings()}),!0});
})()
